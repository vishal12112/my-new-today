<?php
session_start();
if (!isset($_SESSION['email']) && !isset($_SESSION['user_id'])) {
    header("Location: ../view/login.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Dashboard</title>
    <?php include '../assets/cssFile.php'; ?>
</head>

<body>

<?php include '../assets/navbar/navbar.php'; ?>
    <main class=" main content" id="main">
        <div class="row g-4 mb-4">
            <div class="col-sm-6 col-xl-3">
                <div class="card text-white " style="background-color:rgb(54, 62, 134)" ;>
                    <div class="card-body pb-0 d-flex justify-content-center align-items-center">
                        <div>
                            userMaster
                        </div>

                    </div>
                    <div class=" mt-3 mx-3" style="height:70px;">
                        <div class="chart" id="card-chart1" height="70" width="266" style="display: block; box-sizing: border-box; height: 70px; width: 266px;"></div>
                        <div class="chartjs-tooltip" style="opacity: 0; left: 106.333px; top: 101.831px;">
                            <table style="margin: 0px;">
                                <thead class="chartjs-tooltip-header">
                                    <tr class="chartjs-tooltip-header-item" style="border-width: 0px;">
                                        <th style="border-width: 0px;">March</th>
                                    </tr>
                                </thead>
                                <tbody class="chartjs-tooltip-body">
                                    <tr class="chartjs-tooltip-body-item">
                                        <td style="border-width: 0px;"><span style="background: rgb(88, 86, 214); border-color: rgba(255, 255, 255, 0.55); border-width: 2px; margin-right: 10px; height: 10px; width: 10px; display: inline-block;"></span>My First dataset: 84</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="card text-white" style="background-color:rgb(92, 197, 78)" ;>
                    <div class="card-body pb-0 d-flex justify-content-center align-items-center">
                        <div>
                            Client Master
                        </div>

                    </div>
                    <div class=" mt-3 mx-3" style="height:70px;">
                        <div class="chart" id="card-chart2" height="70" width="266" style="display: block; box-sizing: border-box; height: 70px; width: 266px;"></div>
                        <div class="chartjs-tooltip" style="opacity: 0; left: 106.333px; top: 132.625px;">
                            <table style="margin: 0px;">
                                <thead class="chartjs-tooltip-header">
                                    <tr class="chartjs-tooltip-header-item" style="border-width: 0px;">
                                        <th style="border-width: 0px;">March</th>
                                    </tr>
                                </thead>
                                <tbody class="chartjs-tooltip-body">
                                    <tr class="chartjs-tooltip-body-item">
                                        <td style="border-width: 0px;"><span style="background: rgb(51, 153, 255); border-color: rgba(255, 255, 255, 0.55); border-width: 2px; margin-right: 10px; height: 10px; width: 10px; display: inline-block;"></span>My First dataset: 9</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="card text-white " style="background-color:rgb(228, 203, 64)" ;>
                    <div class="card-body pb-0 d-flex justify-content-center align-items-center">
                        <div>
                            Item Master
                        </div>

                    </div>
                    <div class=" mt-3" style="height:70px;">
                        <div class="chart" id="card-chart3" height="70" width="298" style="display: block; box-sizing: border-box; height: 70px; width: 298px;"> </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="card text-white " style="background-color:rgb(168, 62, 62)" ;>
                    <div class="card-body pb-0 d-flex justify-content-center align-items-center">
                        <div>
                            Invoice Master
                        </div>

                    </div>
                    <div class=" mt-3 mx-3" style="height:70px;">
                        <div class="chart" id="card-chart4" height="70" width="266" style="display: block; box-sizing: border-box; height: 70px; width: 266px;"></div>
                    </div>
                </div>
            </div>
            
        </div>    
      
    
      </div>     
      <div class="alert alert-success login-alert" role="alert" id="login-alert" style="position: fixed; bottom: 0; right: 0; margin: 10px; display: none">
           User Successfull Login
      </div>
    </main>
    <?php include '../assets/footer/footer.php'; ?>
    <script >
        $("#login-alert").show();
    </script>
    
</body>

</html>