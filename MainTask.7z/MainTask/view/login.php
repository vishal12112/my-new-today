<?php
session_start();

if (isset($_SESSION['email']) && isset($_SESSION['user_id'])) {
    header("Location: ./dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <?php include '../assets/cssFile.php'; ?>
    <style>
        .screenHeight {
            min-height: 100vh;
        }

        .bg-no-repeat {
            background-repeat: no-repeat;
        }

        .bg-cover {
            background-size: cover;
        }

        .bg-center {
            background-position: center;
        }

        .head {
            font-family: 'Times New Roman', Times, serif;
            font-size: 24px;
            font-weight: var(--base-text-weight-light, 300);
        }

        .logoSan {
            width: 80%;
            height: 70px;
        }
         
    </style>
</head>

<body class="bg-light text-dark">
    <?php include '../assets/navbar/bootstrapToast.php'; ?>
    <div class="screenHeight d-flex justify-content-center align-items-center">
        <div class="container shadow rounded bg-white d-flex flex-wrap">
            <div class="photo  col-lg-6  align-items-center justify-content-center bg-light" style="background-image: url('../assets/images/login.png'); background-size: cover; background-position: center;"></div>
            <div class="col-lg-6 p-5">
                <div class=" text-center mb-4">
                    <img class="logoSan" src="https://sansoftwares.com/wp-content/uploads/2024/06/sansoftwares_newlogo_ajkshdsvash-1.webp" class="img-fluid" alt="Logo">
                </div>
                <h3 class="head text-center mb-4">Sign In To SanSoftwares</h3>
                <form name='loginForm' method="post"> 
                    <div class="mb-3 email"> 
                        <div id="emailErr" class="text-danger"></div>
                        <input id="email" type="email" name="email" class="form-control mt-3 " placeholder="Email" required autocomplete="off">
                    </div>
                    <div id="passwordErr" class="text-danger mb-3"></div>
                    <div class="mb-3 password">
                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                    </div>
                    <button id="login" type="submit" class="btn btn-success w-100 mb-3">
                        Sign In
                    </button>
                    <div class="text-center">
                        <a href="#" class="text-decoration-underline text-center">Forgot Password</a>
                    </div>
                </form>
            </div>
            
            <div class="col-12 text-center mt-3">
                <p class="text-muted">© 2025 SanSoftwares. All rights reserved.</p>
                
            </div>
        </div>
    </div>
    <?php include '../assets/footer/footer.php'; ?>
    
    
</body>

</html>