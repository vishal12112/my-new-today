<?php
session_start();
if (!isset($_SESSION['email']) && !isset($_SESSION['user_id'])) {
    header("Location:../view/login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Master</title>
    <?php include '../assets/cssFile.php'; ?>
</head>

<body>
    <?php include '../assets/navbar/navbar.php'; ?>
    <main class="main content  " id="main">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">All User</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link User-text" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false">Add User</button>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                <?php include '../assets/navbar/bootstrapToast.php'; ?>
                <div class="user-form">
                    <div class="card">
                        <form id="searchForm" class="card-body"  >
                            <div class="row g-3">
                                <div class="col-12 col-sm-6 col-md-3 ">
                                    <input type="text"  name="name" id="u-master-name" class="form-control form-control-sm search-name" placeholder="Name" value="" maxlength="40" autocomplete="off">

                                </div>
                                <div class="col-12 col-sm-6 col-md-3 ">
                                    <input type="text" name="email" id="u-master-email" class="form-control form-control-sm" placeholder="Enter Email" maxlength="25" value="" autocomplete="off">

                                </div>
                                <div class="col-12 col-sm-6 col-md-3 ">
                                    <input type="text" name="phone" id="u-master-phone" maxlength="10" class="form-control form-control-sm" placeholder="Enter Phone Number" value="" autocomplete="off">

                                </div>
                                <div class=" col-12 col-sm-6 col-md-3 search-btn d-flex justify-content-center align-items-center">
                                    <div class="middle"><button id="search" type="submit" data-url="/controller/usermaster.php" class="btn  btn-success search grp"><i class="bi bi-search"></i> Search</button>
                                        <button id="reset" type="reset" class="btn  btn-secondary reset grp"><i class="bi bi-x-circle"></i> Reset</button>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>
                    <div class="card mt-5">
                        <div id="tableList" class="table-responsive card-body">
                        </div>
                    </div>
                    <div class="popup" id="popup" style="display: none;"><?php include '../assets/navbar/popup.php'; ?></div>
                </div>


            </div>
            <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">

                <div class="user-form card">
                    <form method="POST" id="usermasterForm" enctype="multipart/form-data" name="usermasterForm" class="form card-body">
                        <input type="hidden" name="id" id="userId" value="">
                        <div class="row g-3">
                            <div class="col-12 col-sm-6 col-md-3">
                                <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" id="name" class="form-control form-control-sm search-name" placeholder="Name" value="" minlength="3" maxlength="40" autocomplete="off" required>
                                <div class="text-danger err" id="nameErr"></div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-3">
                                <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" id="email" class="form-control form-control-sm" placeholder="Enter Email" value="" maxlength="24" autocomplete="off" required>
                                <div class="text-danger err" id="emailErr"></div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-3">
                                <label for="phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
                                <input type="text" name="phone" id="phone" maxlength="10" class="form-control form-control-sm" placeholder="Enter Phone Number" value="" autocomplete="off" required>
                                <div class="text-danger err" id="phoneErr"></div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-3">
                                <label for="password" class="form-label">Password <span class="text-danger ">*</span></label>
                                <input type="password" name="password" id="password" class="form-control form-control-sm update-password" maxlength="20" placeholder="Password" value="" autocomplete="off" required>
                                <div class="text-danger err" id="passwordErr"></div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-3 imageDiv" id="imageDiv">
                                <label for="image" class="form-label">Upload Image</label>
                                <input type="file" name="image" id="image" class="form-control form-control-sm image" accept="image/*" placeholder="Upload Image" value="">

                                <span id="loadImg" style="cursor: pointer; display: none; margin-top: 30px;">
                                        <a id="removeImage" name="removeImage" style="cursor: pointer; margin-left: 10px;">
                                            <img src="../assets/icons/delete1.png" alt="Delete" style="width: 20px; height: 20px; border-radius: 50%;">
                                        </a>
                                    <img id="preview" src="" alt="Previous Image" class="img-fluid" style="width: 80px; height: 80px; border-radius: 50%; display: block; margin-top: 5px;">
                                </span>
                            </div>
                            
                            <div class="col-12 col-sm-6 col-md-3" id="statusDiv"><label for="status" class="form-label">Status</label>
                            <select name="status" id="status" class="form-select form-select-sm">
                                    <option value="">Select Status</option>
                                    <option value="1" selected>Active</option>
                                    <option value="0">Inactive</option>
                            </select></div>

                        </div>
                        <div class='d-flex justify-content-end'>
                            <button type="submit" id='usermasterSubmit' class="btn btn-success grp submit "><span class="update-icon"><i class="bi bi-send"></i></span><span class="update-text"> Submit</span></i></button>
                            <button type="reset" class="btn btn-secondary reset grp"><i class="bi bi-x-circle"> Reset</i></button>
                        </div>
                    </form>

                </div>
            </div>

    </main>
     <?php include '../assets/footer/footer.php'; ?>
 <script>
        $("#image").change(function() {
            $("#loadImg").show();
            const fileName = URL.createObjectURL(this.files[0]);
            $("#preview").attr("src", fileName);
        });
        $("#removeImage").on("click", function() {
            $("#loadImg").hide();
            $("#preview").attr("src", "");
            $(".image").val("");
     });
    </script>


</body>

</html>