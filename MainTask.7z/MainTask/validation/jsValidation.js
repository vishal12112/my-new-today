const BaseUrl = "http://localhost/maintask";

$("#login").on("click", function (e) {
  e.preventDefault();

  let formData = new FormData(loginForm);

  $.ajax({
    url: BaseUrl + "/controller/login.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (data) {
      if (data == 1) {
        window.location.href = "dashboard.php";
      } else if (data == 0) {
        swal.fire({
          title: "Error!",
          text: "Invalid Username or Password",
          icon: "error",
          confirmButtonText: "Ok",
        });
      } else {
        swal.fire({
          title: "Error!",
          text: `${data}`,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
    },
  });
});

// toggle menu button for side bar

function tabChange() {
  $("#profile-tab").removeClass("active").removeAttr("aria-selected");
  $("#home-tab").addClass("active").attr("aria-selected", "true");
  $("#profile-tab-pane").removeClass("show active");
  $("#home-tab-pane").addClass("show active");
}

function editTabChange() {
  $("#home-tab").removeClass("active").removeAttr("aria-selected");
  $("#profile-tab").addClass("active").attr("aria-selected", "true");
  $(".User-text").text("Edit User");
  $(".Client-text").text("Edit Client");
  $(".Item-text").text("Edit Item");
  $(".Invoice-text").text("Edit Invoice");
  $("#home-tab-pane").removeClass("show active");
  $("#profile-tab-pane").addClass("show active");
  $(".update-text").text("Update");
  $(".update-icon").html('<i class="bi bi-pencil-square"></i> ');
}

function capitalizeFirstLetter(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

$(".salary").keypress(function (e) {
  var currentValue = $(this).val();
  var char = String.fromCharCode(e.keyCode);
  if (char.match(/[^0-9.]/g)) return false;
  if (char === "." && currentValue.indexOf(".") !== -1) return false;
  if (
    currentValue.indexOf(".") !== -1 &&
    currentValue.split(".")[1].length >= 2
  ) {
    return false;
  }
});

$("#phone, #user-master-phone, #pincode").on("input", function () {
  this.value = this.value.replace(/[^0-9]/g, "");
});

$(".search-name").on("input", function () {
  this.value = this.value.replace(/[^a-zA-Z ]/g, "");
});

//// --------------------------------------------------------------------------- All Master Insert and Update All code-----------------------------------------------------
function validateField(field) {
  const fieldName = $(field).attr("name");
  const fieldType = $(field).attr("type");
  const fieldRequired = $(field).attr("required");
  const fieldId = $(field).attr("id");
  const fieldValue = $(field).val().trim();
  const errorSpan = fieldName.split("[")[0] + "Err";



  // For Email Validation
  if (fieldType === "email") {
    if (fieldValue === "") {
      $("#" + errorSpan).html(
        `${capitalizeFirstLetter(fieldName)} is required`
      );
      return false;
    } else if (
      !/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,8}$/.test(fieldValue)
    ) {
      $("#" + errorSpan).html("Please enter a valid email address");
      return false;
    } else {
      $("#" + errorSpan).html("");
      return true;
    }
  }

  // For Name Validation
  if (fieldName === "name" || fieldName === "itemname[]") {
    if (fieldValue === "") {
      $("#" + errorSpan).html(
        `${capitalizeFirstLetter(fieldName.split("[")[0])} is required`
      );
      return false;
    } else if (!/^[a-zA-Z\s]{3,40}$/.test(fieldValue)) {
      $("#" + errorSpan).html(
        `${capitalizeFirstLetter(fieldName).split("[")[0]} must be between 3 to 40 characters`
      );
      return false;
    } else {
      $("#" + errorSpan).html("");
      return true;
    }
  }

  // For Password Validation

  if (fieldId === "password") {
    if (fieldValue === "") {
      $("#" + errorSpan).text(
        `${capitalizeFirstLetter(fieldName)} is required`
      );
      return false;
    } else if (!/^.{6,}$/.test(fieldValue)) {
      $("#" + errorSpan).text(
        `${capitalizeFirstLetter(fieldName)} have minimum 6 characters.`
      );
      return false;
    } else if (!/(?=.*[A-Z])/.test(fieldValue)) {
      $("#" + errorSpan).text(
        `${capitalizeFirstLetter(fieldName)} Atleast one uppercase letter.`
      );
      return false;
    } else if (!/(?=.*\d)/.test(fieldValue)) {
      $("#" + errorSpan).text(`Password Atleast one digit`);
      return false;
    } else if (!/(?=.*[@#-^$!%*?&])/.test(fieldValue)) {
      $("#" + errorSpan).text(`Password have atleast one special character`);
      return false;
    } else {
      $("#" + errorSpan).text("");
      return true;
    }
  }

  // Update Password Validation

  if (fieldId === "update-password") {
    if (fieldValue === "") {
      $("#" + errorSpan).text("");
      return true;
    } else if (!/^.{6,}$/.test(fieldValue)) {
      $("#" + errorSpan).text(
        `${capitalizeFirstLetter(fieldName)} have minimum 6 characters.`
      );
      return false;
    } else if (!/(?=.*[A-Z])/.test(fieldValue)) {
      $("#" + errorSpan).text(
        `${capitalizeFirstLetter(fieldName)} Atleast one uppercase letter.`
      );
      return false;
    } else if (!/(?=.*\d)/.test(fieldValue)) {
      $("#" + errorSpan).text(`Password Atleast one digit`);
      return false;
    } else if (!/(?=.*[@$!%*?&])/.test(fieldValue)) {
      $("#" + errorSpan).text(`Password have atleast one special character`);
      return false;
    } else {
      $("#" + errorSpan).text("");
      return true;
    }
  }

  // For  Phone Number Validation

  if (fieldName === "phone") {
    if (fieldValue === "") {
      $("#" + errorSpan).html(
        `${capitalizeFirstLetter(fieldName)} is required`
      );
      return false;
    } else if (!/^\d{10}$/.test(fieldValue)) {
      $("#" + errorSpan).html(
        `${capitalizeFirstLetter(fieldName)} must be 10 digits`
      );
      return false;
    } else if (fieldValue === "0000000000") {
      $("#" + errorSpan).html(
        `${capitalizeFirstLetter(fieldName)} must be 10 digits`
      );
      return false;
    } else {
      $("#" + errorSpan).html("");
      return true;
    }
  }

  // For Pincode Validation

  if (fieldName === "pincode") {
    if (fieldValue === "") {
      $("#" + errorSpan).html(
        `${capitalizeFirstLetter(fieldName)} is required`
      );
      return false;
    } else if (!/^\d{6}$/.test(fieldValue)) {
      $("#" + errorSpan).html(
        `${capitalizeFirstLetter(fieldName)} must be 6 digits`
      );
      return false;
    } else {
      $("#" + errorSpan).html("");
      return true;
    }
  }

  // For Address Validation

  if (fieldName === "address") {
    if (fieldValue === "") {
      $("#" + errorSpan).html(
        `${capitalizeFirstLetter(fieldName)} is required`
      );
      return false;
    } else if (!/^.{3,}$/.test(fieldValue)) {
      $("#" + errorSpan).html(
        `${capitalizeFirstLetter(fieldName)} must be between 3 to 40 characters`
      );
      return false;
    } else {
      $("#" + errorSpan).html("");
      return true;
    }
  }

  // For Required Fields validation
  if (fieldRequired && fieldValue === "") {
    $("#" + errorSpan).html(`${capitalizeFirstLetter(fieldName.split("[")[0])} is required`);
    return false;
  } else {
    $("#" + errorSpan).html("");
    return true;
  }
}

$("input").on("change paste keyup ", function () {
  validateField(this);
});

const formConfig = {
  usermasterForm: {
    url: BaseUrl + "/controller/usermaster.php",
    idField: "userId",
  },
  clientMasterForm: {
    url: BaseUrl + "/controller/clientmaster.php",
    idField: "clientId",
  },
  itemMasterForm: {
    url: BaseUrl + "/controller/itemmaster.php",
    idField: "itemId",
  },
  invoiceMasterForm: {
    url: BaseUrl + "/controller/invoicemaster.php",
    idField: "invoiceId",
  },
};

$("form").on("submit", function (e) {
  e.preventDefault();
  const formId = $(this).attr("id");
  const formData = formConfig[formId];
  const submitUrl = formData.url;
  const idField = formData.idField;
  const additionalData = {
    type: $("#" + idField).val() ? "update" : "add",
  };
  let isValid = true;
  // alert("hi");
  $(this)
    .find("input")
    .each(function () {
      if (!validateField(this)) {
        isValid = false;
      }
    });

  if (isValid) {
    AllFormSubmit(formId, submitUrl, additionalData);
  }
});

function AllFormSubmit(formId, submitUrl, additionalData = {}) {
  const form = $(`#${formId}`);
  const formData = new FormData(form[0]);
  for (const key in additionalData) {
    formData.append(key, additionalData[key]);
  }
  for (var pair of formData.entries()) {
      console.log(pair[0]+ ', ' + pair[1]); 
      }
  $.ajax({
    url: submitUrl,
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    dataType: "json",
    success: function (response) {
      if (response.success) {
        if (response.same_user == "update") {
          const toastMessage = $("#toastMessage");
          $(toastMessage).text(response.message);
          const successToast = new bootstrap.Toast(
            document.getElementById("successToast"),
            {
              delay: 3000,
            }
          );
          successToast.show();
          window.location.reload();
        }
        const toastMessage = $("#toastMessage");
        $(toastMessage).text(response.message);
        const successToast = new bootstrap.Toast(
          document.getElementById("successToast"),
          {
            delay: 3000,
          }
        );
        successToast.show();
        tabChange();
        reloadTable();
        form[0].reset();
      } else {
        Swal.fire({
          title: "Error!",
          text: `${response}`,
          icon: "error",
          confirmButtonText: "Ok",
        });
      }
    },
  });
}

////// Reset Form form

$(".reset").on("click", function () {
  resetForm();
  reloadTable();
});

function resetForm() {
  $(".err").html("");
  $("input").val("");
  $("#state").trigger("change");
  $("id").val("");
  $(".update-text").text(" Submit");
  $(".update-icon").html('<i class="bi bi-send"></i>');
  $(".update-password").removeAttr("id");
  $(".update-password").attr("id", "password").attr("required", true);
  $(".imageDiv").show();
  $("#loadImg").hide();
}

$("#home-tab").click(function () {
  resetForm();
  $(".User-text").text("Add User");
  $(".Client-text").text("Add Client");
  $(".Item-text").text("Add Item");
  reloadTable();
});

// userMasterEdit

$(document).on("click", ".edit", function () {
  $("#password").removeAttr("required").removeAttr("id");
  $(".update-password").attr("id", "update-password");
  $("#statusDiv").show();
});

//------------------------------------------------------   All master Dalete code  ---------------------------------------------

function deleteAllMasterData(id, submitUrl) {
  $.ajax({
    url: submitUrl,
    type: "POST",
    data: { type: "DELETE", id: id },
    success: function (response) {
      if (response == 1) {
        Swal.fire({
          title: "Error!",
          text: "You can't delete yourself",
          icon: "error",
          confirmButtonText: "Ok",
        });
      } else {
        Swal.fire({
          title: "Success!",
          text: `Delete id ${response} successfully`,
          icon: "success",
          confirmButtonText: "Ok",
        });
      }
      reloadTable();
    },
  });
}

$(document).on("click", ".delete", function () {
  const targetForm = $(this).data("form");
  const formData = formConfig[targetForm];
  const submitUrl = formData.url;
  const id = $(this).attr("delete_id");
  $("#popup").show();
  $("#popup-delete").on("click", function () {
    deleteAllMasterData(id, submitUrl);
    $("#popup").hide();
  });
  $("#popup-cancel").on("click", function () {
    $("#popup").hide();
  });
  $("#close-icon").on("click", function () {
    $("#popup").hide();
  });
});

// ------------------All Master Edit update code----------------------

$(document).on("click", ".edit", function () {
  const id = $(this).attr("edit_id");
  const targetForm = $(this).data("form");
  const formData = formConfig[targetForm];
  const submitUrl = formData.url;
  const idField = formData.idField;
  $("#" + idField).val(id);
  editTabChange();
  $.ajax({
    url: submitUrl,
    type: "POST",
    data: { type: "autofill", id: id },
    dataType: "json",
    success: function (response) {
      var data = response[0];
      $("#" + targetForm + " #status")
        .find("option[value=" + data["status"] + "]")
        .attr("selected", "selected");
      try {
        for (var key in data) {
          console.log(key);
          if (key === "state") {
            $("#" + targetForm + " #state").val(data[key]);
            $("#" + targetForm + " #state").trigger("change");
          } else if (key === "city") {
            setTimeout(() => {
              $("#" + targetForm + " #sCity").text(data["city"]);
              $("#" + targetForm + " #sCity").val(data["city"]);
              console.log($("#" + targetForm + " #sCity").val());
              console.log(data[key]);
            }, 100);
          } else if (key === "image") {
            if (data[key] === "" || data[key] === null) {
              $("#").hide();
              alert(data[key]);
            }
            $("#loadImg").show();
            let filePath = "../assets/images/" + data[key];
            $("#preview").attr("src", filePath);
            console.log(data[key]);
          } else if (data.hasOwnProperty(key)) {
            $("#" + targetForm + " input[name='" + key + "']").val(data[key]);
          }
        }
      } catch (e) {
        console.log("Error in autofill", e);
        return;
      }
    },
  });
});



//// All Master Pagination IS Done Here

function reloadTable() {
    const page_no = $(".active-pagination").attr("id") ?? 1; 
    const page_limit = $("#page_limit").val();
    const local_URL = window.location.href;
    const lastPart = local_URL.split("/").pop();
    const fileName = lastPart.split('.')[0];
    const url = BaseUrl + `/controller/${fileName.replace('-', '')}.php`;
    loadMasters(page_no, page_limit, url);
}

 $(document).on("click", ".pagination_link", function () {
    var page_no = $(this).attr("id");
    var page_limit = $("#page_limit").val();
    var url = $(this).data("url");
    loadMasters(page_no, page_limit, url);
  });
  $(document).on("change", "#page_limit", function (e) {
    e.preventDefault();
    var url = $(this).data("url");
    var page_limit = $(this).val();
    loadMasters(1, page_limit, url);
  });
 $(document).on("click", ".column_sort", function (e) {
    e.preventDefault();
    const column = $(this).attr("data-column") ?? "id";
    const order = $(this).attr("data-order") ?? "desc";
    const url = BaseUrl + $(this).data("url");
    const page_limit = $("#page_limit").val();
    const page_no = $(".active-pagination").attr("id") ?? 1; 
    loadMasters(page_no, page_limit, url, column, order);
  });
  function loadMasters(page, page_limit, url, column, order) {
    $.ajax({
      url: url,
      method: "POST",
      data: { type: "VIEW", page: page, page_limit: page_limit , column: column, order: order },
      success: function (data) {
        $("#tableList").html(data);
      },
    });
  }
$(document).ready(function () {
  reloadTable();
});



// ------------------clientmaster view code----------------------



// All Master Search is Here

$("#search").on("click", function () {
  let form = $("#searchForm")[0];
  const targetUrl = $(this).data("url");
  const page_limit = $("#page_limit").val();
  if (form) {
    let formData = new FormData(form);
    formData.append("type", "search" );
    formData.append("page_limit", page_limit);
    $.ajax({
      url: BaseUrl + targetUrl,
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        $("#tableList").html(response);
      },
    });
  } else {
    console.error("Form element not found!");
  }
});



//
const showSidebar = (toggleId, sidebarId, headerId, mainId) => {
  const toggle = document.getElementById(toggleId),
    sidebar = document.getElementById(sidebarId),
    header = document.getElementById(headerId),
    main = document.getElementById(mainId);

  if (toggle && sidebar && header && main) {
    toggle.addEventListener("click", () => {
      /* Show sidebar */
      sidebar.classList.toggle("show-sidebar");
      /* Add padding header */
      header.classList.toggle("left-pd");
      /* Add padding main */
      main.classList.toggle("left-pd");
    });
  }
};
showSidebar("header-toggle", "sidebar", "header", "main");

/*=============== LINK ACTIVE ===============*/
const sidebarLink = document.querySelectorAll(".sidebar__list a");

function linkColor() {
  sidebarLink.forEach((l) => l.classList.remove("active-link"));
  this.classList.add("active-link");
}

sidebarLink.forEach((l) => l.addEventListener("click", linkColor));



/// Important code  which is given by Sunil sir

// function tablelist(type) {
//   var url = $(".url").val();
//   let formData = new FormData('.searchForm');
//   formData.append("type", type);
//   $.ajax({
//     url: BaseUrl + url + ".php",
//     type: "POST",
//     data: formData,
//     processData: false,
//     contentType: false,
//     success: function (response) {
//       $("#tablelist").html(response);
//     },
//   });
// }

