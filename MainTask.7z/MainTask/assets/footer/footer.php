
<script src="../assets/js/sweetAlert.js"></script>
<script src="../assets/js/jquery.js"></script>
<script src='../validation/jsValidation.js'></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>