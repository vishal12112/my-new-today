<?php 
 
//  define('HOST','localhost');
//  define('USER','root');
//  define('PASS','');
//  define('DATABASE','mainproject');

//  define('TABLE_NAME','users');

//  define('BASE_URL','http://localhost/maintask/');





define('HOST', 'localhost');
define('USER', 'root');
define('PASSWORD', '');
define('DATABASE', 'sanPhp');

define('TABLE_NAME', 'users');




// define("BASE_URL", "http://localhost/final/");






?>