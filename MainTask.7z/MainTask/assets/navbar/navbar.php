<?php $sidebar = ['dashboard' => 'Dashboard,dashboard', 'user-master' => 'User Master,group', 'client-master' => 'Client Master,person','item-master'=>'Item Master,category_search', 'invoice-master' => 'Invoice Master,receipt_long'];

$current_page = basename($_SERVER['PHP_SELF'], '.php');

if($_SESSION['image'] == null || $_SESSION['image'] == ''){
   $_SESSION['image'] = 'profile.png';
}
?>

<header class="header" id="header">
         <div class="header__container">
             <span  class="header__logo">
                <div class="sidebar__user">                 
               <div class="sidebar__img " >
                  <img src="../assets/images/<?php echo isset($_SESSION['image']) ? $_SESSION['image'] : 'profile.png'; ?>" class="profile__img" alt="image">
               </div>
            
               
               <div class="sidebar__info dropdown-toggle" data-toggle="dropdown" >
                  <p class="mt-3" style="cursor: pointer;"> Welcome <?php echo isset($_SESSION['name']) ?$_SESSION['name'] : 'User'; ?></p>
               </div>
               <div class="dropdown-menu">
                 <div class="d-flex justify-item-center"> <img src="../assets/icons/logout.png" alt="" style="width: 25px; height: 25px; margin-right:12px;  ">
                  <span ><a href="../controller/logout.php" class="logout">Logout</a></span>
                 </div>
               </div>
            </div>
            </span>
            
            <button class="header__toggle" id="header-toggle">
               <i class="ri-menu-line"></i>
            </button>
         </div>
      </header>
      <nav class="sidebar" id="sidebar">
         <div class="sidebar__container">
            <div class="sidebar__user">
                 <a class="navbar-brand px-4 py-3 m-0" href="#"><img src="../assets/images/sansoftwares_logo.png" alt="Logo" class="navbar-brand-img" style="width: 220px; height: 40px; margin-left: 11px;"></a>              
            </div>
            <hr class="mt-0 mb-3">
            <div class="sidebar__content">
               <div>
                  <div class="sidebar__list">
                    
                     <?php

            foreach ($sidebar as $key => $value) {
                $parts = explode(',', $value);
                $active_class = ($key === $current_page) ? 'active-link' : '';


            ?>
               
                    <a class="sidebar__link ' <?php echo $active_class; ?>" href="./<?php echo $key; ?>.php">
                        
                        <img src="../assets/icons/<?php echo $parts[1]; ?>.png" alt="" style="width: 30px; height: 30px ; ">
                        
                        <span><?php echo $parts[0]; ?></span>
                    </a>
                
            <?php } ?>
                  </div>
                 
               </div>   
            </div>

            <div class="sidebar__actions">

               <button class="sidebar__link ">
                  <img src="../assets/icons/logout.png" alt="" style="width: 25px; height: 25px ; ">
                  <span ><a href="../controller/logout.php" class="logout">Logout</a></span>
               </button>
            </div>
         </div>
      </nav>


