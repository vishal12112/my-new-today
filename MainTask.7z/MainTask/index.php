<?php 
if (isset($_SESSION['email']) && isset($_SESSION['user_id'])) {
    header('Location: ../view/dashboard.php');
    exit();
}else{
    header('Location: ./view/login.php');
}
?>






function invoiceMasterPdf($data)
{
    // Start output buffering
    ob_start();
    
    // Include the invoice PDF template
    include('../view/invoice-master-pdf.php');
    
    // Get the buffered content
    $html = ob_get_clean();

    return $html;
}
