<?php

include '../assets/config.php';

class Database {
    private $connection;
    private $dbHost;
    private $dbUser;
    private $dbPassword;
    private $dbName;
    public $limit_array =[10,20,30,40,50];

    public function __construct() {
        $this->dbHost = HOST;
        $this->dbUser = USER;
        $this->dbPassword = PASSWORD;
        $this->dbName = DATABASE;
        $this->db_connect();
        // echo "Connection Successfull";
    }

    private function db_connect() {
        try {
            $this->connection = new PDO("mysql:host=$this->dbHost;dbname=$this->dbName", $this->dbUser, $this->dbPassword);
            $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
        }
    }

    public function closeConnection() {
        $this->connection = null;
    }

    public function queryExecuter($sql){
        try{
        $result = $this->connection->query($sql);
        if(!$result){
            throw new Exception(message:$this->connection->errorInfo());
        }
        $count = $result->rowCount();
        if($count > 0){
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }else{
            return $result=0;
        }
        }catch(Exception $e){
            return "Connection Failed:". $e->getMessage();
        }
    }

    public function add($data=array(),$table_name){
        try{
        $columns = implode(", ", array_keys($data));
        $mainData1 = "'" . implode("', '", $data) . "'";
        $sql = "INSERT INTO {$table_name} ($columns) VALUES ($mainData1)";
        
        $stmt = $this->connection->query($sql);
        if ($stmt) {
            return array("success"=>true,"message"=>"Records Data Inserted","function"=>"insert");
        } else {
            return array("success"=>false,"message"=>"Records Data Not Inserted");
        }
        }catch (PDOException $e) {
            return "Connection failed: " . $e->getMessage();
          }
    }

    public function update($data=array(),$table_name){
        try{
        $id = $data['id'];
        unset($data['id']);
        $setUpdate = "";
        foreach ($data as $key => $value) {
             $setUpdate .= "{$key} = '{$value}', ";
        }
        $setUpdate = rtrim($setUpdate, ", ");
        $sql = "UPDATE {$table_name} SET {$setUpdate} WHERE id = {$id}";
        $stmt = $this->connection->query($sql);
        if ($stmt) {
            return array("success"=>true,"message"=>"Record Updated Successfully" ,"function"=>"update");
        } else {
            return array("success"=>false,"message"=>"Record Not Updated Successfully");
        }
        }catch (PDOException $e) {
            return "Connection failed: " . $e->getMessage();
        }
    }

    public function pagination($page_no, $total_records, $page_limit,$display="")
    {     
        $total_page = ($total_records > 0) ? ceil($total_records / $page_limit) : 1; 
        $paginationDisplay1 = ""; 
        $paginationDisplay2 = ""; 
        if ($total_page == 1) {
            $hide = "d-none";
            $paginationDisplay1 = "d-none";
            $paginationDisplay2 = "d-none";
        }else{
            $hide = "";
        }
        
        $previous_page = max(1, $page_no - 1);
        $next_page = min($total_page, $page_no + 1);
        $current_url = "http://" . $_SERVER['HTTP_HOST'] . strtok($_SERVER['REQUEST_URI'], '?'); 
        
        if ($page_no == 1) {
            $paginationDisplay2 = "d-none";
        }
    
        if ($page_no == $total_page) {
            $paginationDisplay1 = "d-none";
        }
        
        $output = '<div><div style="margin-top: 8px;" class="paginationDiv ' . $display . '">';
        
        $output .= '<span class="pagination_link ' . $paginationDisplay2 . '" data-url="' . $current_url . '" style="cursor:pointer; padding:6px; border:1px solid rgb(37, 92, 119); font-size:13px; border-top-left-radius:5px; border-bottom-left-radius:5px;" id="1">First</span>';
        $output .= '<span class="pagination_link ' . $paginationDisplay2 . '" data-url="' . $current_url . '" style="cursor:pointer; padding:6px; font-size:13px; border:1px solid rgb(37, 92, 119);" id="' . $previous_page . '"><<</span>';
        
        for ($i = 1; $i <= $total_page; $i++) {
            if ($i == $page_no) {
                $output .= "<span data-url='$current_url' class=' ".$hide." pagination_link active-pagination ' style='cursor:pointer; padding:6px; border:1px solid rgb(37, 92, 119); color:#fff; font-size:13px; background-color:#157347;' id='$i'>$i</span>";
            }
        }
        $output .= '<span class="pagination_link ' . $paginationDisplay1 . '" data-url="' . $current_url . '" style="cursor:pointer; padding:6px; border:1px solid rgb(37, 92, 119); font-size:13px;" id="' . $next_page . '">>></span>';
        $output .= '<span class="pagination_link ' . $paginationDisplay1 . '" data-url="' . $current_url . '" style="cursor:pointer; font-size:13px; padding:6px; border:1px solid rgb(37, 92, 119); border-top-right-radius:5px; border-bottom-right-radius:5px;" id="' . $total_page . '">Last</span>';
        
        $output .= '</div></div>';
        
        return $output;
    
        
       
    }

    public function dropDown($page_limit){
        $current_url = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        $output = '';
        $output2 = '';
        foreach ($this->limit_array as $option) {
            $output2 .= '<option value="' . $option . '" ' . ($page_limit == $option ? "selected" : "") . '>' . $option . '</option>';
        }
        $output .= '<div class="d-flex justify-content-between" id="pagination_link">
        <div>
            <select class="form-select page_limit" id="page_limit"  data-url="'.$current_url.'" >
               
                ' . $output2 . '
                
            </select>
        </div>';
        return $output;
    }



    
  

}

// $data = new Database();




?>