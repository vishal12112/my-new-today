<?php

include '../model/database.php';
class ClientMaster
{
    private $db = null;

    public function __construct()
    {
        $this->db = new Database();
    }
    function addUpdate($req_type, $post, $table_name)
    {
        $data = [];
        foreach ($post as $key => $value) {
            $data[$key] = $value;
        }
        if ($req_type == "ADD") {
            unset($data['id']);
            $result = $this->db->add($data, $table_name);
            if ($result) {
                echo json_encode($result);
            } else {
                echo json_encode($result);
            }
        } else if ($req_type == "UPDATE") {
            $result = $this->db->update($data, $table_name);
            if ($result) {
                echo json_encode($result);
            } else {
                echo json_encode($result);
            }
        }
    }


    function clientMasterView($table_name, $req_type)
    {
        try {
            $total_data = $this->db->queryExecuter("SELECT count(*) as total FROM {$table_name}");
            $page_limit = isset($_POST['page_limit']) ? (int) $_POST['page_limit'] : 10;
            $page_no = isset($_POST['page']) ? (int) $_POST['page'] : 1;
            $sort_column1 = $_POST['column'] ?? 'status';
            $sort_column2 = $_POST['column'] ?? 'id';
            $sort_order = $_POST['order'] ?? 'DESC';
            $offset = ($page_no - 1) * $page_limit;
            $total_records = $total_data[0]['total'];
            if ($offset < 0) $offset = 0;
            $query = "SELECT id,name,email,phone ,concat(address,' , ',city,' , ',state,' , ',pincode) as address ,status FROM {$table_name}";
            $display = "";
            if ($req_type == "SEARCH") {
                $name = !empty($_POST['name']) ? "%" . trim($_POST['name']) . "%" : "";
                $email = !empty($_POST['email']) ? trim($_POST['email'])  : "";
                $phone = !empty($_POST['phone']) ? trim($_POST['phone'])  : "";
                $address = !empty($_POST['address']) ? "%" . trim($_POST['address']) . "%"  : "";
                if (!empty($name) || !empty($email) || !empty($phone) || !empty($address)) {
                    $query .= " WHERE name LIKE '$name' OR email = '$email' OR phone = '$phone' OR address LIKE '$address' OR city LIKE '$address' OR state LIKE '$address' OR pincode LIKE '$address'";
                    $display = "d-none";
                }
            }
            if($sort_column2=='status'){
                $status ="";
            }else{
                $status = "status DESC,";
            }
            $query .= " ORDER BY {$status} {$sort_column2} {$sort_order} LIMIT {$page_limit} OFFSET {$offset}";
           

            $result = $this->db->queryExecuter($query);
            // print_r($result);
            if (is_countable($result) == 0) {
                $total_data = 0;
            } else {
                $total_data = count($result);
            }
            $output = $this->db->dropDown($page_limit);
            $output .= $this->db->pagination($page_no, $total_records, $page_limit, $display);
            $output .= '</div>';
            $columns = $this->db->queryExecuter("SHOW COLUMNS FROM {$table_name}");
            $columns = array_column($columns, 'Field');
            $output .= '<div class="table-responsive table-wrap">
        <table class="table table-striped table-sm ">
          <thead>
            <tr>
            <th scope="col">Sr.No</th>';
            foreach ($columns as $column) {
                if (in_array($column, ['state', 'country', 'city', 'pincode', 'CreatedAt'])) {
                    continue;
                }
                $new_sort_order = ($sort_column2 == $column && $sort_order == 'ASC') ? 'DESC' : 'ASC';
                $sort_icons = ($sort_column2 == $column && $sort_order == 'ASC') ? '<i class="bi bi-sort-alpha-down"></i>' : '<i class="bi bi-sort-alpha-down-alt"></i>';
                $output .= '<th scope="col">
            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" data-url="/controller/clientmaster.php" style="display: flex; align-items: center; gap: 5px;">
                <span>' . ucfirst($column) . '</span>
                ' . $sort_icons . '
            </a>
        </th>';
            }
            $output .= '<th scope="col">Action</th></tr></thead><tbody>';
            if ($total_data > 0) {
                $sr_no = $offset + 1;
                foreach ($result as $row) {
                    $output .= '<tr><td>' . $sr_no++ . '</td>';
                    foreach ($columns as $column) {
                        if (in_array($column, ['state', 'country', 'city', 'pincode', 'CreatedAt'])) {
                            continue;
                        }

                        if ($column == 'name') {
                            $output .= '<td class="edit" style="cursor: pointer;color:rgb(48, 88, 173); border-radius:5px;" data-form="clientMasterForm" edit_id="' . $row['id'] . '">' . $row['name'] . '</td>';
                            continue;
                        } elseif ($column == 'password' || $column == 'CreatedAt') {
                            continue;
                        } elseif ($column == 'status') {
                            $addClass = ($row[$column] == 1) ? "#157347" : "#BB2D3B";
                            $content = ($row[$column] == 1) ? "Active" : "Inactive";
                            $output .= '<td><div class="toggle border rounded text-white text-center" style="width: 70px; height: 30px; background-color: ' . $addClass . ';" data-form="clientMasterForm" toggle_id="' . $row['id'] . '" toggle_status="' . $row[$column] . '">' . $content . '</div></td>';
                            continue;
                        } elseif ($column == 'image') {
                            if (empty($row[$column])) {
                                $row[$column] = "profile.png";
                            }
                            $output .= '<td><img src="../assets/images/' . $row[$column] . '" class="img-thumbnail" style="width: 50px;"></td>';
                            continue;
                        }
                        $output .= '<td>' . $row[$column] . '</td>';
                    }
                    $output .= '<td>
                <button type="button"  class="btn btn-warning btn-xs edit" data-form="clientMasterForm" edit_id="' . $row['id'] . '"><img src="../assets/icons/update.svg" alt="edit" style="width: 20px;"></button>
                <button type="button" class="btn btn-danger btn-xs delete" data-form="clientMasterForm" delete_id="' . $row['id'] . '"><img src="../assets/icons/delete.png" alt="delete" style="width: 20px;"></button>
              </td></tr>';
                }
            } else {
                $output .= '<tr><td colspan="9" class="text-center text-danger font-weight-bold">No Data Found</td></tr>';
            }
            $output .= '</tbody></table></div>';
            echo $output;
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function clientMasterDelete($table_name)
    {
        $id = $_POST['id'];
        $sql = "DELETE FROM {$table_name} WHERE id = {$id}";
        $result = $this->db->queryExecuter($sql);
        if ($result) {
            echo $id;
        } else {
            echo $id;
        }
    }


    function autofill($table_name)
    {
        $id = $_POST['id'];
        $sql = "SELECT * FROM {$table_name} WHERE id = {$id}";
        $result = $this->db->queryExecuter($sql);
        echo json_encode($result);
    }

    function selectState()
    {
        $sql = "SELECT state_id, state_name FROM state_master";
        $result = $this->db->queryExecuter($sql);
        foreach ($result as $row) {
            echo "<option value='" . $row['state_name'] . "'>" . $row['state_name'] . "</option>";
        }
    }


    function selectCity()
    {
        $cityName = $_POST['state'];
        $sql = "SELECT d.district_name
             FROM district_master d
             JOIN state_master s ON d.state_id = s.state_id
             WHERE s.state_name = '$cityName'";
        $result = $this->db->queryExecuter($sql);
        foreach ($result as $row) {
            echo "<option value='" . $row['district_name'] . "'>" . $row['district_name'] . "</option>";
        }
    }
}


// print_r($_POST);


$req_type = isset($_POST['type']) ? strtoupper($_POST['type']) : "";
unset($_POST['type']);
$post = $_POST;
// print_r($post);
// print_r($req_type);
$table_name = 'clientmaster';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($req_type)) {
    $clientMaster = new ClientMaster();
    if ($req_type == "ADD" || $req_type == "UPDATE") {
        $clientMaster->addUpdate($req_type, $post, $table_name);
    } else if ($req_type == "VIEW" || $req_type == "SEARCH" || $req_type == "SORT") {
        $clientMaster->clientMasterView($table_name, $req_type);
    } else if ($req_type == "DELETE") {
        $clientMaster->clientMasterDelete($table_name);
    } else if ($req_type == "AUTOFILL") {
        $clientMaster->autofill($table_name);
    } else if ($req_type == "STATE") {
        $clientMaster->selectState();
    } else if ($req_type == "CITY") {
        $clientMaster->selectCity();
    }
}
