<?php 
include '../model/database.php';
$table_name = 'usermaster';
$post = $_POST;
class Login{
    private $db = null;
    public function __construct()
    {
        $this->db = new Database();
    }

    function login($post,$table_name){
        if (isset($post['email']) && isset($post['password'])) {
            try{
            $email = $post['email'];
            $password = $post['password'];
            
            $sql = "SELECT *  FROM {$table_name} where email = '$email' and password = '$password' and status = 1";
            $result = $this->db->queryExecuter($sql);
              
            if(is_countable($result) == 0){
               $total_data =0;
             }else{
               $total_data = count($result);
             }
            if($total_data > 0){
                session_start();
                $_SESSION['email'] = $post['email'];
                $_SESSION['user_id'] = $result[0]['id'];
                $_SESSION['name'] = $result[0]['name'];
                $_SESSION['image'] = $result[0]['image'];
                echo 1;
            }else{
                echo 0;
            }
            }catch(Exception $e){
                echo $e->getMessage();
            }
        }else{
           echo 0;
        }
    }
}

$user = new Login();
$user->login($post,$table_name);




?>