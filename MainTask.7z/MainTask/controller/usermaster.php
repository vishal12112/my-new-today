<?php
include '../model/database.php';
session_start();

class UserMaster
{
    private $db = null;

    public function __construct()
    {
        $this->db = new Database();
    }

    function addUpdate($req_type, $post, $table_name)
    {
        $data = [];
        foreach ($post as $key => $value) {
            $data[$key] = $value;
        }
        if ($req_type == "ADD") {
            try {
                unset($data['id']);
                $data['image'] = $_FILES['image']['name'];
                $result = $this->db->add($data, $table_name);
                if ($result) {
                    move_uploaded_file($_FILES['image']['tmp_name'], '../assets/images/' . $_FILES['image']['name']);
                    echo json_encode($result);
                } else {
                    echo json_encode($result);
                }
            } catch (Exception $e) {
                echo json_encode($e->getMessage());
            }
        } else if ($req_type == "UPDATE") {
            try {
                $data['image'] = $_FILES['image']['name'];

                if ($data['password'] == "" || $data['password'] == null) {
                    unset($data['password']);
                }
                if ($data['image'] == "" || $data['image'] == null) {
                    unset($data['image']);
                }
                // print_r($data);
                $result = $this->db->update($data, $table_name);
               
                if ($result) {
                    move_uploaded_file($_FILES['image']['tmp_name'], '../assets/images/' . $_FILES['image']['name']);
                    if($data['id'] == isset($_SESSION['user_id']) && $data['id'] == $_SESSION['user_id']){
                        session_destroy();
                        echo json_encode(['success' => true, 'message' => 'Record Updated Successfully', 'same_user' => 'update']);
                        
                    }else{
                     echo json_encode($result);
                   }
                    
                } else {
                    echo json_encode($result);
                }
            } catch (Exception $e) {
                echo json_encode($e->getMessage());
            }
        }
    }

    function userMasterView($table_name, $req_type)
    {
        try {
            $total_data = $this->db->queryExecuter("SELECT count(*) as total FROM {$table_name}");
            $page_limit = isset($_POST['page_limit']) ? (int) $_POST['page_limit'] : 10;
            $page_no = isset($_POST['page']) ? (int) $_POST['page'] : 1;
            $sort_column1 = $_POST['column'] ?? 'status';
            $sort_column2 = $_POST['column'] ?? 'id';
            $sort_order = $_POST['order'] ?? 'DESC';
            $offset = ($page_no - 1) * $page_limit;
            $total_records = $total_data[0]['total'];
            if ($offset < 0) $offset = 0;
            $query = "SELECT * FROM {$table_name}";
            $display = ""; 
            if ($req_type == "SEARCH") {
                $name = !empty($_POST['name']) ? "%" . trim($_POST['name']) . "%" : "";
                $email = !empty($_POST['email']) ? trim($_POST['email'])  : "";
                $phone = !empty($_POST['phone']) ? trim($_POST['phone'])  : "";
                if(!empty($name) || !empty($email) || !empty($phone)){
                       $query .= " WHERE name LIKE '$name' OR email = '$email' OR phone = '$phone'";
                       $display = "d-none";
                }   
            }
            if($sort_column2=='status'){
                $status ="";
            }else{
                $status = "status DESC,";
            }
            $query .= " ORDER BY {$status} {$sort_column2} {$sort_order} LIMIT {$page_limit} OFFSET {$offset}";
            $result = $this->db->queryExecuter($query);
            if(is_countable($result) == 0){
                $total_data =0;
            }else{
                $total_data = count($result);
            }
            $output = $this->db->dropDown($page_limit);  
            $output .= $this->db->pagination($page_no, $total_records, $page_limit,$display);
            $output .= '</div>';
            $columns = $this->db->queryExecuter("SHOW COLUMNS FROM {$table_name}");
            $columns = array_column($columns, 'Field');
            $output .= '<div class="table-responsive table-wrap">
        <table class="table table-striped table-sm ">
          <thead>
            <tr>
            <th scope="col">Sr.No</th>';
            foreach ($columns as $column) {
                if (in_array($column, ['password', 'CreatedAt'])) {
                    continue;
                }
                if ($column == 'image') {
                    $output .= '<th scope="col"> Image</th>';
                    continue;
                }
                $new_sort_order = ($sort_column2 == $column && $sort_order == 'ASC') ? 'DESC' : 'ASC';
                $sort_icons = ($sort_column2 == $column && $sort_order == 'ASC') ? '<i class="bi bi-sort-alpha-down"></i>' : '<i class="bi bi-sort-alpha-down-alt"></i>'; 
                $output .= '<th scope="col">
            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" data-url="/controller/usermaster.php" style="display: flex; align-items: center; gap: 5px;">
                <span>' . ucfirst($column) . '</span>
                ' . $sort_icons . '
            </a>
        </th>';
            }
            $output .= '<th scope="col">Action</th></tr></thead><tbody>';
            if ($total_data > 0) {
                $sr_no = $offset + 1;
                foreach ($result as $row) {
                    $output .= '<tr><td>' . $sr_no++ . '</td>';
                    foreach ($columns as $column) {
                        if ($column == 'name') {
                            $output .= '<td class="edit" style="cursor: pointer;color:rgb(48, 88, 173); border-radius:5px;" data-form="usermasterForm" edit_id="' . $row['id'] . '">' . $row[$column] . '</td>';
                            continue;
                        } elseif ($column == 'password' || $column == 'CreatedAt') {
                            continue;
                        } elseif ($column == 'status') {
                            $addClass = ($row[$column] == 1) ? "#157347" : "#BB2D3B";
                            $content = ($row[$column] == 1) ? "Active" : "Inactive";
                            $output .= '<td><div class="toggle border rounded text-white text-center" style="width: 70px; height: 30px; background-color: ' . $addClass . ';" data-form="usermasterForm" toggle_id="' . $row['id'] . '" toggle_status="' . $row[$column] . '">' . $content . '</div></td>';
                            continue;
                        } elseif ($column == 'image') {
                            if (empty($row[$column])) {
                                $row[$column] = "profile.png";
                            }
                            $output .= '<td><img src="../assets/images/' . $row[$column] . '" class="img-thumbnail" style="width: 50px;"></td>';
                            continue;
                        }
                        $output .= '<td>' . $row[$column] . '</td>';
                    }
                    $output .= '<td>
                <button type="button"  class="btn btn-warning btn-xs edit" data-form="usermasterForm" edit_id="' . $row['id'] . '"><img src="../assets/icons/update.svg" alt="edit" style="width: 20px;"></button>
                <button type="button" class="btn btn-danger btn-xs delete" data-form="usermasterForm" delete_id="' . $row['id'] . '"><img src="../assets/icons/delete.png" alt="delete" style="width: 20px;"></button>
              </td></tr>';
                }
            } else {
                $output .= '<tr><td colspan="9" class="text-center text-danger font-weight-bold">No Data Found</td></tr>';
            }
            $output .= '</tbody></table></div>';
            echo $output;
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }



    function userMasterDelete($table_name)
    {
        try {
            
            $id = $_POST['id'];
            if($_SESSION['user_id'] ==$id){
               echo 1;
            }else{
              $sql = "DELETE FROM {$table_name} WHERE id = {$id}";
               $result = $this->db->queryExecuter($sql);
                if ($result) {
                  echo $id;
                } else {
                 echo $id;
                }
        }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }


    function autofill($table_name)
    {
        try {
            $id = $_POST['id'];
            $sql = "SELECT * FROM {$table_name} WHERE id = {$id}";
            $result = $this->db->queryExecuter($sql);
            unset($result[0]['password']);
            echo json_encode($result);
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
}



$req_type = strtoupper($_POST['type'] ?? "");
unset($_POST['type']);
$post = $_POST;
$table_name = 'usermaster';


// print_r($post);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($req_type)) {
    $userMaster = new UserMaster();
    if ($req_type == "ADD" || $req_type == "UPDATE") {
        $userMaster->addUpdate($req_type, $post, $table_name);
    } elseif ($req_type == "VIEW" || $req_type == "SEARCH") {
        $userMaster->userMasterView($table_name, $req_type);
    } elseif ($req_type == "DELETE") {
        $userMaster->userMasterDelete($table_name);
    } elseif ($req_type == "AUTOFILL") {
        $userMaster->autofill($table_name);
    }
}

