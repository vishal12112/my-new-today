<?php
include '../model/database.php';
session_start();

include '../vendor/autoload.php';


use Dompdf\Dompdf;
use Dompdf\Options;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


class InvoiceMaster
{
    private $db = null;
    public function __construct()
    {
        $this->db = new Database();
    }

    function addUpdate($req_type, $post)
    {
        if ($req_type == "ADD") {
            try {
                $invoiceData = [
                    'invoice_no' => $post['invoice_no'],
                    'client_id' => $post['client_id'],
                    'invoice_date' => $post['invoice_date'],
                    'total_amount' => $post['total_amount'],
                ];
                $result = $this->db->add($invoiceData, 'invoicemaster');
                $sql = "SELECT id FROM invoicemaster WHERE invoice_no = {$invoiceData['invoice_no']}";
                $result2 = $this->db->queryExecuter($sql);
                $invoiceId = $result2[0]['id'];
                $itemDetails = [];
                foreach ($post['item_id'] as $key => $value) {
                    $itemDetails[] = [
                        'invoice_id' => $invoiceId,
                        'item_id' => $value,
                        'quantity' => $post['quantity'][$key],
                        'price' => $post['price'][$key],
                        'total_price' => $post['amount'][$key],
                    ];
                }
                foreach ($itemDetails as $item) {
                    $result = $this->db->add($item, 'invoicedetails');
                }
                echo json_encode(["success" => true, 'status' => 'success', 'message' => 'Invoice created successfully']);
            } catch (Exception $e) {
                echo json_encode($result);
            }
        }
    }

    function invoiceMasterView($table_name, $req_type)
    {
        try {
            $total_data = $this->db->queryExecuter("SELECT count(*) as total FROM {$table_name}");
            $page_limit = isset($_POST['page_limit']) ? (int) $_POST['page_limit'] : 10;
            $page_no = isset($_POST['page']) ? (int) $_POST['page'] : 1;
            $sort_column1 = $_POST['column'] ?? 'status';
            $sort_column2 = $_POST['column'] ?? 'id';
            $sort_order = $_POST['order'] ?? 'DESC';
            $offset = ($page_no - 1) * $page_limit;
            $total_records = $total_data[0]['total'];
            if ($offset < 0) $offset = 0;
            $query = "SELECT  im.id,   im.invoice_no,  im.invoice_date, cm.name as client_name, concat(cm.address, ' , ', cm.city, ' , ', cm.state, ' , ', cm.pincode) as address, cm.email as client_email, cm.phone as client_phone, im.total_amount FROM invoicemaster im JOIN clientmaster cm ON im.client_id = cm.id;";
            $display = "";
            // if ($req_type == "SEARCH") {
            //     $name = !empty($_POST['name']) ? "%" . trim($_POST['name']) . "%" : "";
            //     $email = !empty($_POST['email']) ? trim($_POST['email'])  : "";
            //     $phone = !empty($_POST['phone']) ? trim($_POST['phone'])  : "";
            //     $address = !empty($_POST['address']) ? "%" . trim($_POST['address']) . "%"  : "";
            //     if (!empty($name) || !empty($email) || !empty($phone) || !empty($address)) {
            //         $query .= " WHERE name LIKE '$name' OR email = '$email' OR phone = '$phone' OR address LIKE '$address' OR city LIKE '$address' OR state LIKE '$address' OR pincode LIKE '$address'";
            //         $display = "d-none";
            //     }
            // }
            if ($sort_column2 == 'status') {
                $status = "";
            } else {
                $status = "status DESC,";
            }
            $query .= " ORDER BY {$status} {$sort_column2} {$sort_order} LIMIT {$page_limit} OFFSET {$offset}";
            $result = $this->db->queryExecuter($query);
            if (is_countable($result) == 0) {
                $total_data = 0;
            } else {
                $total_data = count($result);
            }
            $output = $this->db->dropDown($page_limit);
            $output .= $this->db->pagination($page_no, $total_records, $page_limit, $display);
            $output .= '</div>';
            $columns = ['id', 'invoice_no', 'invoice_date', 'client_name', 'address', 'client_email', 'client_phone', 'total_amount'];
            $output .= '<div class="table-responsive  table-wrap">
        <table class="table table-striped table-sm ">
          <thead>
            <tr>
            <th scope="col">Sr.No</th>';
            foreach ($columns as $column) {
                $new_sort_order = ($sort_column2 == $column && $sort_order == 'ASC') ? 'DESC' : 'ASC';
                $sort_icons = ($sort_column2 == $column && $sort_order == 'ASC') ? '<i class="bi bi-sort-alpha-down"></i>' : '<i class="bi bi-sort-alpha-down-alt"></i>';
                $output .= '<th scope="col">
            <a class="column_sort text-black " href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" data-url="/controller/invoicemaster.php" style="display: flex; align-items: center; gap: 5px;">
                <span>' . ucfirst($column) . '</span>
                ' . $sort_icons . '
            </a>
        </th>';
            }
            $output .= '<th scope="col">Action</th></tr></thead><tbody>';
            if ($total_data > 0) {
                $sr_no = $offset + 1;
                foreach ($result as $row) {
                    $output .= '<tr><td>' . $sr_no++ . '</td>';
                    foreach ($columns as $column) {
                        if (in_array($column, ['email', 'PDF', 'CreatedAt'])) {
                            continue;
                        }

                        if ($column == 'client_name') {
                            $output .= '<td class="edit" style="cursor: pointer;color:rgb(48, 88, 173); border-radius:5px;" data-form="invoiceMasterForm" edit_id="' . $row['id'] . '">' . $row['client_name'] . '</td>';
                            continue;
                        } elseif ($column == 'password' || $column == 'CreatedAt') {
                            continue;
                        } elseif ($column == 'status') {
                            $addClass = ($row[$column] == 1) ? "#157347" : "#BB2D3B";
                            $content = ($row[$column] == 1) ? "Send" : "Pending";
                            $output .= '<td><div class="toggle border rounded text-white text-center" style="width: 70px; height: 30px; background-color: ' . $addClass . ';" data-form="invoiceMasterForm" toggle_id="' . $row['id'] . '" toggle_status="' . $row[$column] . '">' . $content . '</div></td>';
                            continue;
                        } elseif ($column == 'total_amount') {
                            $output .= '<td class="d-flex justify-content-end">' . number_format($row[$column], 2) . '</td>';
                            continue;
                        }
                        $output .= '<td>' . $row[$column] . '</td>';
                    }
                    $output .= '<td><button type="button" class="btn btn-primary btn-xs pdf-generate" pdf_id="' . $row['id'] . '">
        <i class="bi bi-file-earmark-pdf-fill"></i>
    </button>
    <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo" class="btn btn-primary btn-xs email-send" email_id ="' . $row['id'] . '" userEmail="' . $row['client_email'] . '" userName="' . $row['client_name'] . '">
        <i class="bi bi-envelope"></i>
    </button>

                <button type="button"  class="btn btn-warning btn-xs edit" data-form="invoiceMasterForm" edit_id="' . $row['id'] . '"><img src="../assets/icons/update.svg" alt="edit" style="width: 20px;"></button>
                <button type="button" class="btn btn-danger btn-xs delete" data-form="invoiceMasterForm" delete_id="' . $row['id'] . '"><img src="../assets/icons/delete.png" alt="delete" style="width: 20px;"></button>
              </td></tr>';
                }
            } else {
                $output .= '<tr><td colspan="9" class="text-center text-danger font-weight-bold">No Data Found</td></tr>';
            }
            $output .= '</tbody></table></div>';
            echo $output;
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    public function autoCompleteTextAndClientDetail()
    {
        $name = !empty($_POST['name']) ? trim($_POST['name'])  : "";
        $exactMatchQuery = "SELECT id, name, email, phone, CONCAT(address, ' , ', city, ' , ', state, ' , ', pincode) as address 
                        FROM clientmaster 
                        WHERE name = '$name'";
        $exactMatchResult = $this->db->queryExecuter($exactMatchQuery);
        if ($exactMatchResult != 0) {
            echo json_encode(['status' => 'success', 'type' => 'clientDetail', 'data' => $exactMatchResult[0]]);
            return;
        }
        $query = "SELECT distinct(name) from clientmaster where name like '%$name%'";
        $result = $this->db->queryExecuter($query);
        if (is_countable($result) == 0) {
            $total_data = 0;
        } else {
            $total_data = count($result);
        }
        $output = '<ul class="list-group autocomplete-list">';
        if ($total_data > 0) {
            foreach ($result as $row) {
                $output .= '<li class="list-group-item autocomplete-item">' . $row['name'] . '</li>';
            }
        } else {
            $output .= '<li class="list-group-item autocomplete-item text-danger">Name not found</li>';
        }
        $output .= '</ul>';

        echo json_encode(['status' => 'success', 'type' => 'autoComplete', 'data' => $output]);
        return;
    }

    public function autoCompleteTextAndItemDetail()
    {
        $itemname = !empty($_POST['itemname']) ? $_POST['itemname']  : "";
        $exactMatchQuery = "SELECT id,price
                        FROM itemmaster 
                        WHERE itemname = '$itemname'";
        $exactMatchResult = $this->db->queryExecuter($exactMatchQuery);
        if ($exactMatchResult != 0) {
            echo json_encode(['status' => 'success', 'type' => 'itemDetail', 'data' => $exactMatchResult[0]]);
            return;
        }
        $query = "SELECT distinct(itemname) from itemmaster where itemname like '%$itemname%'";
        $result = $this->db->queryExecuter($query);
        if (is_countable($result) == 0) {
            $total_data = 0;
        } else {
            $total_data = count($result);
        }
        $output = '<ul class="list-group autocomplete-list">';
        if ($total_data > 0) {
            foreach ($result as $row) {
                $output .= '<li class="list-group-item autocomplete-item">' . $row['itemname'] . '</li>';
            }
        } else {
            $output .= '<li class="list-group-item autocomplete-item text-danger">Name not found</li>';
        }
        $output .= '</ul>';

        echo json_encode(['status' => 'success', 'type' => 'autoComplete', 'data' => $output]);
        return;
    }

    function invoiceMasterDelete($table_name)
    {
        $id = $_POST['id'];
        $sql = "DELETE FROM {$table_name} WHERE id = {$id}";
        $result = $this->db->queryExecuter($sql);
        if ($result) {
            echo $id;
        } else {
            echo $id;
        }
    }



    function allDataTakenFormDatabase($id){
        $sql = "SELECT  
            im.invoice_no,  
            im.invoice_date,  
            cm.name AS client_name,  
            cm.email AS client_email,  
            cm.phone AS client_phone,  
            CONCAT(cm.address, ', ', cm.city, ', ', cm.state, ', ', cm.pincode) AS address,  
            GROUP_CONCAT(itm.itemname SEPARATOR ', ') AS item_names,
            GROUP_CONCAT(idt.quantity SEPARATOR ', ') AS quantities,
            GROUP_CONCAT(itm.price SEPARATOR ', ') AS item_prices,
            im.total_amount
        FROM invoicemaster im
        JOIN clientmaster cm ON im.client_id = cm.id
        JOIN invoicedetails idt ON im.id = idt.invoice_id
        JOIN itemmaster itm ON idt.item_id = itm.id
        WHERE im.id = {$id}
        GROUP BY im.id";
         return $this->db->queryExecuter($sql);
    }

    function invoiceNo()
    {
        $sql = "SELECT invoice_no FROM invoicemaster ORDER BY invoice_no DESC LIMIT 1";
        $result = $this->db->queryExecuter($sql);
        if ($result) {
            echo $result[0]['invoice_no'] + 1;
        } else {
            echo 0;
        }
    }
    function invoiceMasterPdf($data)
    {

        $invoice_no = $data['invoice_no'];

        $invoice_date = date('d/m/Y', strtotime($data['invoice_date']));
        $client_name = $data['client_name'];
        $client_email = $data['client_email'];
        $client_phone = $data['client_phone'];
        $address = $data['address'];
        $item_names = explode(',', $data['item_names']);
        $quantities = explode(',', $data['quantities']);
        $item_prices = explode(',', $data['item_prices']);
        $total_amount = $data['total_amount'];


        $html = '<html>
     <head>
      <meta charset="UTF-8">
      <title>SanSoftware Invoice</title>
      <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            color: #2c3e50;
       
            padding: 20px;
        }
        .invoice-box {
            width: 98%;
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 10px;
           
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .company-info, .invoice-details {
            width: 100%;
            margin-bottom: 20px;
        }
        .company-info td, .invoice-details td {
            vertical-align: top;
            padding: 5px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table th, .table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .table th {
            background-color: #f8f9fa;
        }
        .total-box {
            width: 100%;
            padding: 10px;
            border-top: 2px solid #2c3e50;
            background: #f8f9fa;
            margin-top: 10px;
        }
        .amount-in-words {
            font-style: italic;
            color: #4e6f8f;
            margin-top: 10px;
        }
       </style>
       </head>
       <body>';
        $html .= ' <div class="invoice-box">
        <div class="header">
        <img src="http://localhost/MainTask/assets/images/sansoftwares_logo.png" alt="SanSoftware Logo" width="200">
        </div>
        <table class="company-info">
            <tr>
                <td>
                    <strong>SanSoftware Inc.</strong><br>
                    3232, Gurugram<br>
                    Tel: 1234567880<br>
                    Email: billing@sansoftware.com
                </td>
                <td style="text-align: right;">
                    <strong>INVOICE</strong><br>
                    Invoice #:' . $invoice_no . '<br>
                    Date: ' . $invoice_date . '<br>
                </td>
            </tr>
        </table>
        <table class="invoice-details">
            <tr>
                <td>
                    <strong>Client Details:</strong><br>
                    Client Name: ' . $client_name . '<br>
                    Client Address: ' . $address . '<br>
                    Mobile No.: ' . $client_phone . '<br>
                    Email: ' . $client_email . '<br>

                </td>
            </tr>
        </table>
        <table class="table">
            <thead>
                <tr>
                    <th width="50%">Item Name</th>
                    <th width="15%" style="text-align: center;">Quantity</th>
                    <th width="15%" style="text-align: right;">Unit Price</th>
                    <th width="20%" style="text-align: right;">Total</th>
                </tr>
            </thead>';
        foreach ($item_names as $i => $item_name) {
            $html .= '<tr>
                <td>' . $item_names[$i] . '</td>
                <td style="text-align: center;">' . $quantities[$i] . '</td>
                <td style="text-align: right;">' . $item_prices[$i] . '</td>
                <td style="text-align: right;">' . $item_prices[$i] * $quantities[$i] . '</td>
            </tr>';
        }
        $html .= '<div class="total-box align-right">
            <table width="100%">
                <tr>
                    <td><strong>Total Amount:</strong></td>
                    <td style=";">' . $total_amount . '</td>
                </tr>
            </table>
        </div>
        <div class="amount-in-words">
            <strong>Amount in Words:</strong> ten thousand rupees only
        </div>
    </div>
</body>
</html>';
        return $html;
    }

    function pdfGenerate($id)
    {
        $result = $this->allDataTakenFormDatabase($id);
        $dompdf = new Dompdf();
        $options = new Options();
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isPhpEnabled', true);
        $options->set('isJavascriptEnabled', true);
        $options->set('isCssFloatEnabled', true);
        $options->set('isRemoteEnabled', true);
        $options->set('isImageEnabled', true);
        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($this->invoiceMasterPdf($result[0]));
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();
        $folderPath = '../assets/pdf/';
        $fileName = 'invoice_' . $id . '.pdf';
        $filePath = $folderPath . $fileName;
        if (!file_exists($folderPath)) {
            mkdir($folderPath, 0777, true);
        }
        file_put_contents($filePath, $dompdf->output());
        $pdfUrl = 'maintask/../' . $filePath;
        echo json_encode(['status' => 'success', 'pdf_url' => $pdfUrl]);
        exit;
    }


    function emailMessage($message,$result){

        $item_names = explode(',', $result['item_names']);
        $quantities = explode(',', $result['quantities']);
        $item_prices = explode(',', $result['item_prices']);
    
      $html ='<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            text-align: center;
            padding-bottom: 20px;
            border-bottom: 2px solid #ddd;
        }
        .header img {
            max-width: 150px;
        }
        .header h2 {
            margin: 10px 0 0;
            color: #333;
        }
        .content {
            padding: 20px 0;
        }
        .details {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .details th, .details td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        .details th {
            background-color: #f8f8f8;
        }
        .footer {
            text-align: center;
            padding: 20px 0;
            font-size: 14px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
             <img src="https://sansoftwares.com/wp-content/uploads/2024/06/sansoftwares_newlogo_ajkshdsvash-1.webp" alt="SanSoftware Logo" style="width: 450px;">
            <h2>SanSoftware pvt ltd</h2>
        </div>
        <div class="content">
            <p>Dear ' . $result['client_name'] . ',</p>
            <p>Thank you for your business. Please find your invoice details below:</p>';

            $html .= '<br> ' . $message . ' <br>';

            $html .= '<table class="details">
                <tr>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total</th>
                </tr>';
            foreach ($item_names as $i => $item_name) {
                $html .= '<tr>
                    <td>' . $item_name . '</td>
                    <td>' . $quantities[$i] . '</td>
                    <td>' . $item_prices[$i] . '</td>
                    <td>' . $item_prices[$i] * $quantities[$i] . '</td>
                </tr>';
            }
            $html .= '<tr>
                <td colspan="3" style="text-align: right;">Total Amount:</td>
                <td>' . $result['total_amount'] . '</td>
            </tr>
        </table>
            <p>If you have any questions, feel free to contact us.</p>
        </div>
        <div class="footer">
            <p>Best Regards,<br>From SanSoftware pvt ltd</p>
        </div>
    </div>
</body>
</html>
';
  return $html;
    }

    function sendMessage( $post) {
        // $client_email = $post['recipient-email'];

        
        $id = $post['email_id'];
        $result = $this->allDataTakenFormDatabase($id);
        $message = $post['message-text'];
        // $to = $client_email;
        $subject = 'Invoice';
        $message = $this->emailMessage($message,$result[0]);
        $attachment = '../assets/pdf/invoice_' . $id . '.pdf';   
        $mail = new PHPMailer(true);
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'vishalvishwakarma8009@gmail.com';
        $mail->Password = 'kpvurrdmaxniutgq';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->setFrom('vishalvishwakarma8009@gmail.com');
        $mail->addAddress('vishalvishwakarma8009@gmail.com');
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;
        $mail->addAttachment($attachment);
        if ($mail->send()) {
            echo json_encode(['status' => 'success', 'message' => 'Email sent successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to send email']);
        }
    }
}




$req_type = strtoupper($_POST['type'] ?? "");
unset($_POST['type']);
$post = $_POST;

$table_name = 'invoicemaster';

// print_r($post);
// print_r($req_type);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $invoiceMaster = new InvoiceMaster();
    if (isset($post['name']) && $req_type == "CLIENTDETAIL") {
        $invoiceMaster->autoCompleteTextAndClientDetail();
    }
    if (isset($post['itemname']) && $req_type == "ITEMDETAIL") {
        // print_r($post);
        $invoiceMaster->autoCompleteTextAndItemDetail();
    }
    if ($req_type == "ADD" || $req_type == "UPDATE") {
        $invoiceMaster->addUpdate($req_type, $post, $table_name);
    } elseif ($req_type == "VIEW" || $req_type == "SEARCH") {
        $invoiceMaster->invoiceMasterView($table_name, $req_type);
    } elseif ($req_type == "DELETE") {
        $invoiceMaster->invoiceMasterDelete($table_name);
    } else if ($req_type == "INVOICENO") {
        $invoiceMaster->invoiceNo();
    }else if ($req_type == "PDFGENERATER") {
        $id = $post['id'];
        $invoiceMaster->pdfGenerate($id);
    }else if($req_type == "SENDMESSAGE"){
        $invoiceMaster->sendMessage($post);
    }
}
