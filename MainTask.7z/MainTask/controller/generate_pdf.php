<!DOCTYPE html>

<body>
    <div class="invoice-box">
        <div class="header">
        <img src="../assets/images/sansoftwares_logo.png" alt="SanSoftware Logo" width="200">
        </div>
        <table class="company-info">
            <tr>
                <td>
                    <strong>SanSoftware Inc.</strong><br>
                    123 Main Street<br>
                    Tel: 1234567880<br>
                    Email: billing@sansoftware.com
                </td>
                <td style="text-align: right;">
                    <strong>INVOICE</strong><br>
                    Invoice #: INV-2024-001<br>
                    Date: February 6, 2025<br>
                    Due Date: March 7, 2025
                </td>
            </tr>
        </table>
        <table class="invoice-details">
            <tr>
                <td>
                    <strong>Bill To:</strong><br>
                    Tech Solutions Inc.<br>
                    456 Innovation Drive<br>
                    San Francisco, CA 94105<br>
                    United States
                </td>
            </tr>
        </table>
        <table class="table">
            <thead>
                <tr>
                    <th width="50%">Item Name</th>
                    <th width="15%" style="text-align: center;">Quantity</th>
                    <th width="15%" style="text-align: right;">Unit Price</th>
                    <th width="20%" style="text-align: right;">Total</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Chips</td>
                    <td style="text-align: center;">4</td>
                    <td style="text-align: right;">$10</td>
                    <td style="text-align: right;">$40</td>
                </tr>
            </tbody>
        </table>
        <div class="total-box">
            <table width="100%">
                <tr>
                    <td><strong>Subtotal:</strong></td>
                    <td style="text-align: right;">$19,000.00</td>
                </tr>
                <tr>
                    <td><strong>Tax (10%):</strong></td>
                    <td style="text-align: right;">$1,900.00</td>
                </tr>
                <tr>
                    <td><strong>Total:</strong></td>
                    <td style="text-align: right;"><strong>$20,900.00</strong></td>
                </tr>
            </table>
        </div>
        <div class="amount-in-words">
            <strong>Amount in Words:</strong> Twenty Thousand Nine Hundred Dollars Only
        </div>
    </div>
</body>
</html>
